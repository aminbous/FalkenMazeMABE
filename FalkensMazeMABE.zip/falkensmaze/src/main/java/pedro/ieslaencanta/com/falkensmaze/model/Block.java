/*
 * Clase Block que implementa Serializable
 */
package pedro.ieslaencanta.com.falkensmaze.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
public class Block implements Serializable {

    private String value;

    // Constructor por defecto
    public Block() {
        this.value = null;
    }

    // Método para obtener el valor del bloque
    public String getValue() {
        return this.value;
    }

    // Método para establecer el valor del bloque
    public void setValue(String value) {
        this.value = value;
    }

    // Método para verificar si el bloque está vacío
    public boolean isEmpty() {
        return this.value == null;
    }
}
