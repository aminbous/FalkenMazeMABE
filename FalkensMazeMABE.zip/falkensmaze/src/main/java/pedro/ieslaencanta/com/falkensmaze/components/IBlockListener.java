/*
 * Interfaz IBlockListener para definir métodos de escucha de eventos de bloque
 */
package pedro.ieslaencanta.com.falkensmaze.components;

public interface IBlockListener {

    // Método llamado cuando se hace clic en un bloque
    public void onClicked(Block b);

    // Método llamado cuando se hace doble clic en un bloque
    public void onDoubleClicked(Block b);
}
