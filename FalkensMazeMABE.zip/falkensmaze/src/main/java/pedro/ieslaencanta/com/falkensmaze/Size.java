/*
 * Clase Size que implementa Serializable, Cloneable y Comparable<Size>
 */
package pedro.ieslaencanta.com.falkensmaze;

import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
public class Size implements Cloneable, Comparable<Size>, Serializable {

    private int width;
    private int height;

    // Constructores
    public Size() {
    }

    public Size(int width, int height) {
        this.width = width;
        this.height = height;
    }

    // Método clone para realizar una copia superficial del objeto
    public Object clone() throws CloneNotSupportedException {
        return new Size(this.getWidth(), this.getHeight());
    }

    // Método equals para comparar dos objetos Size
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Size)) {
            return false;
        }
        if (this.getWidth() == ((Size) (o)).getWidth() && this.getHeight() == ((Size) (o)).getHeight()) {
            return true;
        } else {
            return false;
        }

    }

    // Método compareTo para comparar dos objetos Size
    @Override
    public int compareTo(Size o) {
        if (this.getWidth() == o.getWidth() && this.getHeight() == o.getHeight()) {
            return 0;
        }
        if (this.getWidth() < o.getWidth()) {
            return -1;
        } else {
            return 1;
        }
    }

    // Método toString para obtener una representación en cadena del objeto
    public String toString() {
        return "W:" + this.width + " H:" + this.height;
    }

    // Getters y setters para width y height
    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

}
